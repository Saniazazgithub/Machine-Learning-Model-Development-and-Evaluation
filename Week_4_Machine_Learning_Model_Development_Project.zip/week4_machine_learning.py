import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_curve, roc_auc_score
)

# Load data
df = pd.read_csv("Mall_Customers_Week3.csv")
if "index" in df.columns:
    df = df.drop(columns=["index"])
df.columns = [
    "CustomerID", "Gender", "Age",
    "Annual Income (k$)", "Spending Score (1-100)"
]
df = df.drop_duplicates().dropna()

# Binary target: 1 = high spender, 0 = not high spender
df["HighSpender"] = (df["Spending Score (1-100)"] >= 60).astype(int)

# Predictors
X = df[["Gender", "Age", "Annual Income (k$)"]]
y = df["HighSpender"]

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# Preprocessing
preprocessor = ColumnTransformer([
    ("num", StandardScaler(), ["Age", "Annual Income (k$)"]),
    ("cat", OneHotEncoder(drop="if_binary", handle_unknown="ignore"), ["Gender"])
])

# Logistic Regression pipeline
model = Pipeline([
    ("preprocess", preprocessor),
    ("classifier", LogisticRegression(max_iter=1000, random_state=42))
])

model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# Evaluation
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
auc = roc_auc_score(y_test, y_prob)

print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1-score:", f1)
print("ROC-AUC:", auc)
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# Confusion matrix
sns.heatmap(
    confusion_matrix(y_test, y_pred),
    annot=True, fmt="d", cbar=False,
    xticklabels=["Not High", "High"],
    yticklabels=["Not High", "High"]
)
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.savefig("01_confusion_matrix.png", dpi=180, bbox_inches="tight")
plt.close()

# ROC curve
fpr, tpr, _ = roc_curve(y_test, y_prob)
plt.plot(fpr, tpr, label=f"AUC = {auc:.3f}")
plt.plot([0, 1], [0, 1], linestyle="--")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend()
plt.savefig("02_roc_curve.png", dpi=180, bbox_inches="tight")
plt.close()
