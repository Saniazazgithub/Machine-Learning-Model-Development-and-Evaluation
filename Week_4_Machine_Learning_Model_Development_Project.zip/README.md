# Week 4 — Machine Learning Model Development and Evaluation

**Made by Sania Azaz**

A supervised machine learning project that predicts whether a Mall Customer is a high spender using Logistic Regression.

## Model
- Algorithm: Logistic Regression
- Target: HighSpender (Spending Score >= 60)
- Features: Gender, Age, Annual Income
- Split: 80% training / 20% test
- Random state: 42

## Evaluation
Accuracy: 0.550
Precision: 0.273
Recall: 0.231
F1-score: 0.250
ROC-AUC: 0.670

## Visualizations
- Confusion Matrix
- ROC Curve
- Model Performance Metrics
- Training vs Test Accuracy

## Files
- `Week_4_Machine_Learning_Model_Development_Report.docx`
- `Week_4_Technical_Coding_Documentation.docx`
- `week4_machine_learning.py`
- `Mall_Customers_Week3.csv`
- `Mall_Customers_Week4_Prepared.csv`
- `visualizations/`
- `requirements.txt`
